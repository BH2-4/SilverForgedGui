# Claude Opus 4.7 — Stage 2 Implementation Prompt

你现在要在现有 Next.js Global Demand Engine V1 项目中，接入已经准备好的 SilverHeritage-GZ v1.0 贵州苗族银饰文化知识库。

## 0. 最高优先级原则

这是“文化知识系统”，不是普通 AI 内容生成。

绝对禁止：
- 凭模型记忆新增苗族文化事实
- 自己编造纹样寓意、象征意义、历史来源
- 把“苗族银饰”当成一个统一风格
- 把雷山、台江、剑河、黄平的资料混为一谈
- 把 AI 推断写入 official/documented 字段
- 未经授权抓取/打包第三方图片

所有文化事实必须能够追溯到 `data/sources.json`。

---

# 1. 先扫描现有项目

不要破坏已经完成的 Global Demand Engine V1。

先检查：
- package.json
- app/
- components/
- lib/
- types/
- 当前 API
- 当前 Global Design Brief 类型
- 当前 UI 路由

先运行：
- pnpm exec tsc --noEmit
- pnpm run lint

如果已有错误，先记录，不要擅自重构。

---

# 2. 接入数据

将 `SilverHeritage-GZ-v1/data/` 复制到项目：

`data/heritage/`

必须保留：

- sources.json
- projects.json
- regional_styles.json
- heritage_items.json
- motifs.json
- crafts.json
- people.json
- cultural_rules.json
- dataset_manifest.json

不要把 JSON 内容重新生成一遍。
不要删除 source_ids。
不要把 documented_meaning 为 null 的记录补成 AI 猜测。

---

# 3. 建立 Heritage Repository

新增：

lib/heritage/
├── types.ts
├── repository.ts
├── search.ts
└── guardrail.ts

要求：

## repository.ts

提供：
- getAllHeritageItems()
- getProjectById()
- getRegionalStyle()
- getMotifs()
- getCrafts()
- getPeople()
- getSources()
- getRules()

## search.ts

V1 先不要引入 pgvector。

先实现“结构化 + 关键词检索”。

输入：
- market
- product_type
- style[]
- emotion[]
- occasion
- cultural_visibility
- design_keywords[]

输出：
- top candidates
- match score
- matched fields
- region
- source_ids
- evidence_level

必须可解释。

例如：

{
  "candidate_id": "MOTIF-004",
  "match_score": 0.86,
  "matched_reasons": [
    "user prefers nature-related visual language",
    "candidate is documented in Jianhe silver ornament sources"
  ],
  "source_ids": ["SRC-004"]
}

不要生成“花鸟象征爱情”之类没有来源的解释。

---

# 4. Cultural Match Engine

新增 API：

POST /api/cultural-match

输入：
Global Design Brief

输出：

{
  "matches": [
    {
      "id": "...",
      "type": "motif | item | regional_style | craft",
      "name": "...",
      "region": "...",
      "match_score": 0,
      "visual_fit": 0,
      "regional_fit": 0,
      "wearability_fit": 0,
      "cultural_confidence": 0,
      "why": "...",
      "source_ids": ["..."],
      "evidence_level": "official"
    }
  ],
  "guardrail_notes": []
}

---

# 5. Cultural Guardrail

新增：

lib/heritage/guardrail.ts

至少实现：

## Rule A — Source Required

没有 source_ids：
禁止作为文化事实返回。

## Rule B — Regional Accuracy

例如：
剑河资料只能作为剑河证据。
不能因为用户喜欢龙，就说“龙是雷山银饰”。

## Rule C — Motif Meaning

如果 documented_meaning === null：

AI只能说：
“documented motif / visual subject”

不能说：
“symbolizes love / protection / rebirth”。

## Rule D — AI Interpretation

如果需要 AI 对用户需求做现代设计转译：

必须字段：
`interpretation_type: "ai_inference"`

不能伪装成官方文化事实。

---

# 6. UI：新增 Cultural Match 页面

新增：

/cultural-match

视觉语言必须与现有 Global Design Studio 一致。

页面结构：

HERO

HERITAGE MATCH

“Your story, interpreted through documented Guizhou heritage.”

↓

用户 Design DNA

↓

3 个 Heritage Candidates

每个 Candidate：

- 名称
- 地域
- 类型
- Match %
- Why this direction?
- Cultural evidence
- Source
- Evidence level

↓

CULTURAL NOTE

例如：

“Visual subject documented in Jianhe official heritage materials.”

↓

按钮：

“Explore this direction →”

---

# 7. 不要伪造“AI文化寓意”

如果用户输入：

“I want something representing a new beginning.”

系统不能直接：

“蝴蝶代表新生，所以我们选择蝴蝶。”

除非数据库里有 documented_meaning。

正确方式：

“Your preference for transformation-oriented imagery led us to consider documented butterfly imagery in the work record of a Leishan representative inheritor. The source does not establish a universal symbolic meaning for butterfly, so this is presented as a design interpretation rather than a cultural fact.”

---

# 8. 暂时不要做

不要现在做：
- pgvector
- Supabase
- PostgreSQL
- 登录
- 支付
- 电商
- 用户数据库
- 爬虫
- 图片训练
- 图像生成
- 匠人端

这些放 Stage 3/4。

---

# 9. 测试

必须新增：

- source traceability test
- regional attribution test
- unsupported meaning test
- empty search test
- Global Design Brief → Cultural Match integration test

测试必须验证：

1. 每个 match 都有 source_ids
2. source_ids 能在 sources.json 找到
3. 没有来源的文化寓意不会出现
4. 雷山/台江/剑河/黄平不会被混淆
5. API 返回结构稳定

最后运行：

pnpm exec tsc --noEmit
pnpm run lint
pnpm run build

---

# 10. 完成后汇报

输出：

## Stage 2 完成报告

### Data
- source count
- project count
- item count
- motif count
- craft count
- people count
- cultural rule count

### Engineering
- files added
- API routes
- search algorithm
- guardrail rules

### Verification
- TypeScript
- ESLint
- Build
- Test results

### Product
给出一条完整 Demo：

Global Demand
→ Design DNA
→ Cultural Match
→ Evidence
→ Cultural Guardrail

最后告诉我：

“下一阶段是否值得进入 AI Silver Design”。

